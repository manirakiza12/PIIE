<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DailyAttendances extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'class_id', 'section_id', 'student_id', 'status', 'session_id', 'school_id', 'timestamp',
        'programme_id', 'intake_session_id',
    ];

    public function student()
    {
        return $this->belongsTo(User::class, 'student_id');
    }
}
