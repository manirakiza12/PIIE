<?php

namespace App\Support\CourseRegistration;

use App\Models\CourseOffering;
use App\Models\CourseRegistration;
use DomainException;
use Illuminate\Support\Collection;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\DB;
use Throwable;

/**
 * Administrator bulk registration and confirmation for one Course Allocation.
 *
 * Every student is processed on its own through CourseRegistrationService,
 * which re-applies CourseOfferingEligibility, locking and the unique
 * registration key at execution time. One refused student never aborts the
 * batch; each outcome is summarised with an administrator-readable reason.
 */
class CourseOfferingRegistrationBatch
{
    public const REGISTERED = 'registered';
    public const CONFIRMED = 'confirmed';
    public const ALREADY = 'already';
    public const SKIPPED = 'skipped';

    public function __construct(private CourseRegistrationService $registrations)
    {
    }

    public function register(CourseOffering $offering, iterable $studentIds, int $actorId): array
    {
        $schoolId = (int) $offering->school_id;
        $outcomes = collect($studentIds)->map(fn ($id) => (int) $id)->filter(fn ($id) => $id > 0)->unique()->values()
            ->map(function (int $studentId) use ($offering, $schoolId, $actorId): array {
                $name = $this->studentName($schoolId, $studentId);
                if ($name === null) {
                    return $this->outcome('A selected student', self::SKIPPED, 'This student was not found in this institution.');
                }
                $existing = CourseRegistration::query()->where('school_id', $schoolId)
                    ->where('course_offering_id', $offering->id)->where('student_id', $studentId)->first();
                if ($existing) {
                    return $existing->status === CourseRegistration::STATUS_DROPPED
                        ? $this->outcome($name, self::SKIPPED, 'Previously withdrawn from this Course Allocation; re-registration is not allowed.')
                        : $this->outcome($name, self::ALREADY, 'Already registered.');
                }
                try {
                    $registration = $this->registrations->registerStudentForOffering($schoolId, $studentId, (int) $offering->id, null, $actorId);
                } catch (DomainException $exception) {
                    return $this->outcome($name, self::SKIPPED, $this->readable($exception, 'This student could not be registered; the academic office should review the record.'));
                } catch (Throwable $exception) {
                    report($exception);
                    return $this->outcome($name, self::SKIPPED, 'This student could not be registered. Please try again.');
                }

                return $registration->wasRecentlyCreated
                    ? $this->outcome($name, self::REGISTERED, 'Registered.')
                    : $this->outcome($name, self::ALREADY, 'Already registered.');
            });

        return $this->summary('registration', $outcomes);
    }

    public function confirm(CourseOffering $offering, iterable $registrationIds, int $actorId): array
    {
        $schoolId = (int) $offering->school_id;
        $outcomes = collect($registrationIds)->map(fn ($id) => (int) $id)->filter(fn ($id) => $id > 0)->unique()->values()
            ->map(function (int $registrationId) use ($offering, $schoolId, $actorId): array {
                $registration = CourseRegistration::query()->where('school_id', $schoolId)
                    ->where('course_offering_id', $offering->id)->whereKey($registrationId)->first();
                if (! $registration) {
                    return $this->outcome('A selected registration', self::SKIPPED, 'This registration was not found for this Course Allocation.');
                }
                $name = $this->studentName($schoolId, (int) $registration->student_id) ?? 'A selected student';
                if ($registration->status === CourseRegistration::STATUS_CONFIRMED) {
                    return $this->outcome($name, self::ALREADY, 'Already confirmed.');
                }
                if ($registration->status === CourseRegistration::STATUS_DROPPED) {
                    return $this->outcome($name, self::SKIPPED, 'Dropped registrations cannot be confirmed.');
                }
                try {
                    $confirmed = $this->registrations->confirmRegistration($schoolId, $registrationId, $actorId);
                } catch (ValidationException $exception) {
                    $reason = collect($exception->errors())->flatten()->first()
                        ?? 'Registration cannot be confirmed until at least 20% of current-session fees are paid or an authorised student waiver is active.';
                    return $this->outcome($name, self::SKIPPED, $reason);
                } catch (DomainException $exception) {
                    return $this->outcome($name, self::SKIPPED, $this->readable($exception, 'This registration needs academic review before it can be confirmed.'));
                } catch (Throwable $exception) {
                    report($exception);
                    return $this->outcome($name, self::SKIPPED, 'This registration could not be confirmed. Please try again.');
                }

                return $confirmed->status === CourseRegistration::STATUS_CONFIRMED
                    ? $this->outcome($name, self::CONFIRMED, 'Confirmed.')
                    : $this->outcome($name, self::SKIPPED, 'This registration could not be confirmed.');
            });

        return $this->summary('confirmation', $outcomes);
    }

    /** Eligibility messages are already administrator-facing; older service messages may name internals. */
    private function readable(DomainException $exception, string $fallback): string
    {
        $message = $exception->getMessage();
        foreach (['provenance', 'snapshot', 'tenant', 'Membership', 'Curriculum', 'Subject', 'AcademicYear', 'User', ' id', '#'] as $internal) {
            if (str_contains($message, $internal)) {
                return $fallback;
            }
        }

        return $message;
    }

    private function studentName(int $schoolId, int $studentId): ?string
    {
        return DB::table('users')->where('school_id', $schoolId)->where('id', $studentId)->where('role_id', 7)->value('name');
    }

    private function outcome(string $student, string $result, string $reason): array
    {
        return ['student' => $student, 'result' => $result, 'reason' => $reason];
    }

    private function summary(string $action, Collection $outcomes): array
    {
        return [
            'action' => $action,
            'reviewed' => $outcomes->count(),
            'registered' => $outcomes->where('result', self::REGISTERED)->count(),
            'confirmed' => $outcomes->where('result', self::CONFIRMED)->count(),
            'already' => $outcomes->where('result', self::ALREADY)->count(),
            'skipped' => $outcomes->where('result', self::SKIPPED)->count(),
            'details' => $outcomes->where('result', '!=', self::REGISTERED)->where('result', '!=', self::CONFIRMED)->values()->all(),
        ];
    }
}
